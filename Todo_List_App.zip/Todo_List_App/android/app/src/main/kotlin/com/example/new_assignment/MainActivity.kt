package com.example.new_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
