import 'dart:io';
void main() {
  print("Exiting the application...");
  exit(0); 
}
